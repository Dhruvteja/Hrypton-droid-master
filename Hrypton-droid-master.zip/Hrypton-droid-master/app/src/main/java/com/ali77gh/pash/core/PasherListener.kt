package com.ali77gh.pash.core

interface PasherListener {
    fun onReady(pass:String)
}